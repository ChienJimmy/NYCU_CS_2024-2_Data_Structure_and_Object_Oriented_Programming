// IContainer.h for Ex9_15 
#pragma once

interface class IContainer
{
  double Volume();                     // Function for calculating a volume
  void ShowVolume();                   // Function to display a volume
};
